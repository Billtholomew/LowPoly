#include "stdafx.h"
#include <iostream>
#include <ctime>
#include <omp.h>

#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
using namespace cv;

int main(int argc, const char** argv)
{
}